import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-typeloader',
  templateUrl: './typeloader.component.html',
  styleUrls: ['./typeloader.component.css']
})
export class TypeloaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
